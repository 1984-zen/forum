import openpyxl
from openpyxl.utils import column_index_from_string
import re
import pymysql
import time
import random
from datetime import datetime
from datetime import time as dt
import smtplib, pickle, os


#wb=openpyxl.load_workbook('patient_list0717.xlsx')
#ws=wb.active

db=pymysql.connect('localhost', 'chunjoe', 'M122016594', 'mr', port=3336)
cursor=db.cursor()
cursor.execute('use mr')
cursor.execute('set names utf8')

def get_id(pre_id):
    pre_id=str(pre_id)
    add_zero=8-len(pre_id)
    return '0'*add_zero+pre_id


def create_views():
    
    try: cursor.execute("drop view adm_dx, adm_mx, adm_dxmx, adm_others, adm, opd_a, opd_tmpdx, opd_dx, opd_mx, opd_others, opd, opd_icd,"
                        " adm_old_dx, adm_old_mx, opd_old_mx, opd_old, adm_old_dxmx, adm_old, adm_old_datetmp, adm_old_date")
                        
                        
    except: pass
    ##create admission views
    cursor.execute("create view adm_dx as select Chart_No as uid, Medical_Sn as aid, Digest_Content as dx, Trans_Time as a_date from emr_digest where Digest_Type_Id='DC' and Sub_Title_Id='Diagnose'")
    cursor.execute("create view adm_mx as select Chart_No as uid, Medical_Sn as aid, Digest_Content as mx from emr_digest where Digest_Type_Id='DC' and Sub_Title_Id='Out Plan'")
    cursor.execute("create view adm_dxmx as select adm_dx.uid, dx, adm_dx.aid, mx from adm_dx inner join adm_mx on adm_dx.uid=adm_mx.uid and adm_dx.aid=adm_mx.aid")
    cursor.execute("create view adm_others as select Doctor_Name as dr, Bed_No as bed, Discharge_Date as date, Medical_Sn as aid, Chart_No as uid from emr_medical_record where Source_Type_Id='I'")
    cursor.execute("create view adm as select adm_dxmx.aid, adm_dxmx.uid, dx, mx, dr, bed, date from adm_dxmx inner join adm_others ON adm_dxmx.uid=adm_others.uid and adm_dxmx.aid=adm_others.aid ")
    
    cursor.execute("create view adm_old_dx as select Chart_No as uid, Medical_Sn as aid, Digest_Content as dx, Trans_Time as a_date from emr_digest where Digest_Type_Id='00' and Sub_Title_Id='出院：'")
    cursor.execute("create view adm_old_mx as select Chart_No as uid, Medical_Sn as aid, Digest_Content as mx from emr_digest where Digest_Type_Id='00' and Title_Id='出院指示'")
    cursor.execute("create view adm_old_dxmx as select adm_old_dx.aid, adm_old_dx.uid, dx, mx from adm_old_dx left join adm_old_mx on adm_old_dx.uid=adm_old_mx.uid and adm_old_dx.aid=adm_old_mx.aid")
    cursor.execute("create view adm_old_datetmp as select Medical_Sn as aid, Chart_No as uid, substring(Digest_Content, 1, 10) as adm_date from emr_digest where Digest_Type_Id='AD' and Title_Id='病情說明'")
    cursor.execute("create view adm_old_date as select aid, uid, str_to_date(adm_date, '%Y/%m/%d') as adm_date from adm_old_datetmp")
    cursor.execute("create view adm_old as select adm_old_dxmx.aid, adm_old_dxmx.uid, dx, mx, null, null, adm_date from adm_old_dxmx inner join adm_old_date on adm_old_dxmx.uid=adm_old_date.uid and adm_old_dxmx.aid=adm_old_date.aid ")
    


    ## create opd views
    cursor.execute("create view opd_a as select Medical_Sn as oid, Chart_No as uid, Order_Content as a, Order_Time as date from emr_medical_order where SOAP_Type_Id='A' and Order_Plan_No='0'")
    cursor.execute("create view opd_tmpdx as select Medical_Sn as oid, Order_Content as dx from emr_medical_order where SOAP_Type_Id='P' and Order_Category_Id='PA'")
    cursor.execute("create view opd_dx as select opd_a.uid, opd_a.oid, dx, date from opd_a inner join opd_tmpdx on opd_a.oid=opd_tmpdx.oid")
    cursor.execute("create view opd_mx as select Medical_Sn as oid, Chart_No as uid, Order_Content as mx, Order_Time as date from emr_medical_order where SOAP_Type_Id='P' and Order_Category_Id='PA'")
    cursor.execute("create view opd_others as select Doctor_Name as dr, Medical_Sn as oid, Chart_No as uid from emr_medical_record where Source_Type_Id='O'")
    cursor.execute("create view opd as select opd_a.oid, opd_a.uid, a, date, dr from opd_a inner join opd_others on opd_a.uid=opd_others.uid and opd_a.oid=opd_others.oid")
    cursor.execute("create view opd_icd as select Medical_Sn as oid, Chart_No as uid, Diagnosis_Name as a, Trans_Time as date from emr_medical_diagnosis")
    cursor.execute("create view opd_old_mx as select Medical_Sn as oid, Chart_No as uid, Order_Content as mx, Order_Time as date from emr_medical_order where SOAP_Type_Id='P' and Order_Category_Id='E'")
    cursor.execute("create view opd_old as select opd_icd.oid, opd_icd.uid, a, date, dr from opd_icd left join opd_others on opd_icd.uid=opd_others.uid and opd_icd.oid=opd_others.oid")


    '''OPD/adm view還比table快  所以沒建'''

    try: cursor.execute("drop table adm_table")
    except: pass
    cursor.execute("create table if not exists adm_table (aid char(12) not null primary key)")
    cursor.execute("alter table adm_table add column uid int(8) unsigned zerofill not null")
    cursor.execute("alter table adm_table add column dx text character set utf8")
    cursor.execute("alter table adm_table add column mx text character set utf8")
    cursor.execute("alter table adm_table add column dr char(10) character set utf8")
    cursor.execute("alter table adm_table add column bed char(10)")
    cursor.execute("alter table adm_table add column adm_date datetime")

    cursor.execute("insert ignore into adm_table select * from adm")
    print('74: commit')
    db.commit()
    cursor.execute("insert ignore into adm_table select * from adm_old")
    print('77: commit')
    db.commit()

    
'''abandoned area'''
#    try: cursor.execute("drop table opd_mx_table, opd_table")
#    except: pass
#    cursor.execute("create table if not exists opd_table (oid char(15) not null primary key)")
#    cursor.execute("alter table opd_table add column uid int(8) unsigned zerofill not null")
#    cursor.execute("alter table opd_table add column a text character set utf8")
#    cursor.execute("alter table opd_table add column opd_date datetime")
#    cursor.execute("alter table opd_table add column dr char(10) character set utf8")
#
#    cursor.execute("create table if not exists opd_mx_table (oid char(15) not null)")
#    cursor.execute("alter table opd_mx_table add column uid int(8) unsigned zerofill not null")
#    cursor.execute("alter table opd_mx_table add column mx text character set utf8")
#    cursor.execute("alter table opd_mx_table add column opd_date datetime")
#
#    cursor.execute("insert ignore into opd_table select * from opd")
#    cursor.execute("insert into opd_mx_table select * from opd_mx")
#    db.commit()


def create_report_table():
    ## create text report views
    exams=[('tte', ('1660201', '1600201')), \
           ('cath', ('1660350', '1600305', '1600312', '1600313', '1600314', '1600006','1660006')), \
           ('holter', ('1600105',)), ('tte', ('1600201', '1660201', '1600202', '1660202', '1600203', '1660203')), \
           ('ekg', ('1600101', '1660101')), \
           ('ccta', ('9130308', '9130307')),
           ('thallium', ('9310308',)),
           ('IM_duplexLE', ('1600207','1660207')),
           ('RADIO_duplexLE', ('9410708', '9400708')),
           ('extremityCT', ('9130603','9130602','9160603','9160602')),
           ('abdCT', ('9130403','9130407','9160403','9160407')),
           ('abdEcho', ('9400301', '9400304', '9410301','9410304'))
           ]
   
    for exam, codes in exams:
        #只要abdEcho
        if exam not in {'abdEcho'}:
            continue

        try: cursor.execute("drop view {}_tmp, {}".format(exam, exam))
        except: pass

        codes_order=""
        for code in codes:
            codes_order+="ChargeCode='{}' or ".format(code)
        cursor.execute("create view {}_tmp as select RequestNo as lid, ChartNo as uid from emrcharge where {}".format(exam, codes_order[:-4]))
        cursor.execute("create view {} as select {}_tmp.lid, {}_tmp.uid, emrreport.ReportTime as date, emrreport.ReportText as report from {}_tmp inner join emrreport on {}_tmp.lid=emrreport.RequestNo".format(exam, exam, exam, exam, exam))


        try: cursor.execute("drop table {}_table".format(exam))
        except: pass
        cursor.execute("create table if not exists {}_table (lid char(12) not null primary key)".format(exam))
        cursor.execute("alter table {}_table add column uid int(8) unsigned zerofill not null".format(exam))
        cursor.execute("alter table {}_table add column exam_date datetime".format(exam))
        cursor.execute("alter table {}_table add column report text character set utf8".format(exam))
        cursor.execute("ALTER TABLE {}_table ADD KEY `uid` (`uid`,`exam_date`)".format(exam))

        if exam in ['ccta', 'cath']:
            cursor.execute("insert into {}_table select * from {} on duplicate key update {}_table.report=concat({}_table.report, values(report))".format(exam, exam, exam, exam))
        else:
            cursor.execute("insert ignore into {}_table select * from {}".format(exam, exam))
        
        db.commit()




def create_lab_table():
    ## create lab data (scalar) views
    labs=[('crea', ('8203CREA', '8202CREA')), ('egfr', ('8202eGFR', '8203eGFR')), ('chol', ('8203CHOL', )), ('tg', ('8203TRIG', )), \
          ('ldl', ('8203LDL-C', )), ('hdl', ('8203HDL-C', )), ('hba1c', ('4201HbA1c', '8201HbA1c','8203HbA1c',)), \
          ('hb', ('8201Hb', )), ('uric', ('8203URIC', )),
          ('alt',('8202ALT', '8203ALT')),
          ('ast',('8202AST', '8203AST'))]

    for exam, codes in labs:
        #只要alt, ast
        if exam not in {'alt', 'ast'}:
            continue

        try: cursor.execute("drop view {}_tmp, {}".format(exam, exam))
        except: pass

        codes_order=""
        for code in codes:
            codes_order+="ItemCode='{}' or ".format(code)
        cursor.execute("create view {} as select emrlabdata.RequestNo as lid, emrlabdata.ChartNo as uid, emrlabdata.ConfirmTime as date, emrlabdata.TestValue as value from emrlabdata where {}".format(exam, codes_order[:-4]))


        try: cursor.execute("drop table {}_table".format(exam))
        except: pass
        cursor.execute("create table if not exists {}_table (lid char(12) not null primary key)".format(exam))
        cursor.execute("alter table {}_table add column uid int(8) unsigned zerofill not null".format(exam))
        cursor.execute("alter table {}_table add column exam_date datetime".format(exam))
        cursor.execute("alter table {}_table add column value char(8)".format(exam))
        cursor.execute("ALTER TABLE {}_table ADD KEY `uid` (`uid`,`exam_date`)".format(exam))

        cursor.execute("insert ignore into {}_table select * from {}".format(exam, exam))
        db.commit()




if __name__=='__main__':

    # create_views()
#     create_report_table()
    create_lab_table()
    pass